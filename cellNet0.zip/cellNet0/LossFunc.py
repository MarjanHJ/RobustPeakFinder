import torch
import torch.nn as nn
import torch.nn.functional as F

class FocalLossV1(nn.Module):
    def __init__(self,
                 alpha=0.25,
                 gamma=2,
                 reduction='mean',):
        super(FocalLossV1, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.crit = nn.BCEWithLogitsLoss(reduction='none')

    def forward(self, logits, label):
        '''
        logits and label have same shape, and label data type is long
        args:
            logits: tensor of shape (N, ...)
            label: tensor of shape(N, ...)
        '''

        # compute loss
        logits = logits.float() # use fp32 if logits is fp16
        with torch.no_grad():
            alpha = torch.empty_like(logits).fill_(1 - self.alpha)
            alpha[label == 1] = self.alpha

        probs = torch.sigmoid(logits)
        pt = torch.where(label == 1, probs, 1 - probs)
        ce_loss = self.crit(logits, label.float())
        loss = (alpha * torch.pow(1 - pt, self.gamma) * ce_loss)
        if self.reduction == 'mean':
            loss = loss.mean()
        if self.reduction == 'sum':
            loss = loss.sum()
        return loss

#PyTorch
# class DiceLoss(nn.Module):
#     def __init__(self, weight=None, size_average=True):
#         super(DiceLoss, self).__init__()
# 
#     def forward(self, inputs, targets, smooth=1):
#         
#         #comment out if your model contains a sigmoid or equivalent activation layer
#         #inputs = F.sigmoid(inputs)       
#         
#         #flatten label and prediction tensors
#         inputs = inputs.view(-1)
#         targets = targets.view(-1)
#         
#         intersection = (inputs * targets).sum()                            
#         dice = (2.*intersection + smooth)/(inputs.sum() + targets.sum() + smooth)  
#         
#         return 1 - dice
    
    
class dice_loss(nn.Module):
    def __init__(self):
        super(dice_loss, self).__init__()
        
        
    def forward(self, pred, target):    
        pred = pred.contiguous()
        target = target.contiguous()   
        smooth = 1 

        intersection = (pred * target).sum(dim=2).sum(dim=2)
    
        loss = (1 - ((2 * intersection + smooth) / (pred.sum(dim=2).sum(dim=2) + target.sum(dim=2).sum(dim=2) + smooth)))
    
        return loss.mean()    
    

class diffraLossSq_perImage(nn.Module):
    def __init__(self):
        super(diffraLossSq_perImage, self).__init__()

    def forward(self, inputs, targets):
                
        #flatten label and prediction tensors
        #return(((((targets - inputs)**2).mean(0))**0.5).mean())
        return((((targets - inputs)**2).mean(1).mean(1).mean(1))**0.5)

class diffraLoss(nn.Module):
    def __init__(self):
        super(diffraLoss, self).__init__()

    def forward(self, inputs, targets):
        return((((targets - inputs)**2).mean())**0.5)

class justLoss(nn.Module):
    def __init__(self):
        super(justLoss, self).__init__()

    def forward(self, inputs, targets):
        return((targets - inputs).mean())

def calc_loss(pred, target, bce_weight=0.5):
    bce = F.binary_cross_entropy_with_logits(pred, target)

    pred = F.sigmoid(pred)
    dice = dice_loss(pred, target)

    loss = bce * bce_weight + dice * (1 - bce_weight)

    #metrics['bce'] += bce.data.cpu().numpy() * target.size(0)
    #metrics['dice'] += dice.data.cpu().numpy() * target.size(0)
    #metrics['loss'] += loss.data.cpu().numpy() * target.size(0)

    return loss