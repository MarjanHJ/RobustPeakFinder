#Descend According To Order Statistics 
#This is DATOS: a sampling method to help Stochastic Gradient Descent
#with SGD, it is said that 
#   1 - the samples must be coming from a uniform density
#   2 - samples must be gathered with replacement
#   3 - Sample size my be small in the beginning but can be 
#          large close to the end
#The question is if sorting data can help with estimation of 
#    1 - proper next sample
#    2 - next sample's learning rate
#    3 - next sample's number of epochs
#    4 - next sample's size
#This method is based on FLKOS, an optimization method for minimizing         
#Least K-th Order Statistics. This method is developed with financial support 
#from AMALEA project in CFEL/DESY, 2020-2021.
#The technical contribution was only from:
#    Author: Alireza Sadri : <ARSadri> <at> <gmail> <.com>                        

import numpy as np

#import matplotlib as mpl
#mpl.use('agg')

import matplotlib.pyplot as plt

import torch
import os
import gc
import time
import logging

import RobustGaussianFittingLibrary as RGF

def get_n_params(model):
    """returns number of parameters in the pytorch model
    """
    pp=0
    for p in list(model.parameters()):
        nn=1
        for s in list(p.size()):
            nn = nn*s
        pp += nn
    return pp
    
def printModelSize(model):
    """returns size of pytorch model in bytes
    """
    model_state_dict = model.state_dict()
    nB = 0
    for keyCnt in range(len(model_state_dict)):
        nB += model_state_dict[list(\
            model_state_dict.keys())[keyCnt]].to('cpu').numpy().nbytes
    str2return = 'The model has ' + str(get_n_params(model)) + ' parameters.'
    str2return += 'Size of the model on GPU is ' + str(nB/(1024*1024)) + ' MB'
    return(str2return)

def createDIR(inDIR):
    """Creates a directory if its not there already"""
    try:
        if(not os.path.isdir(inDIR)):
            os.system('mkdir -p ' + inDIR)
        return(True)
    except:
        print('I cannot make the directory!')
        print('Do you have permission to make ', inDIR)
        print('are you using MS-Windows? I am using mkdir. you need coreutils')
        exit()

class datos:
    """Descend according to Order Statistics
    This object keeps track of the data points that have been shown
    to a machine for training. This optimization takes care of the part of
    data that a machine is yet to learn. Indeed this is an optimization method
    that can handle data given to gradient descend for each fitting of a model.
    """
    def __init__(self, 
        torchModel,
        lossFunc,
        optimizer,
        device,
        dataMakerFunc,
        infer_size,
        classes, 
        logDIR = None,
        n_k = 10, 
        sampleSize = 1,
        order='ascend', 
        n_epochs = 4, 
        n_kSweeps = 16,
        fit2FixedK = 0.9,
        OutliersThreshold = 4,
        n_correctFunc = None,
        priorIndices = None,
        indicesUpdate_showProgress = False,
        numTestDataPoints = 0,
        sortAt = 'eachkUpdate',
        fit2What = None,
        Fit2LeastSeenRate = 2,
        plotMSSEs = False,
        plotRelativeOrders = False,
        saveCanvasInds = None,
        logTitle = None,
        includeCloseOutliers = False,
        lr_schedule = None,
        dataDriven_LR_and_epochs = False,
        dataDriven_LR_near = None,
        dataDriven_LR_far = None,
        dataDriven_nEpochs_near = None,
        dataDriven_nEpochs_far = None,
        dataDriven_sampleSize_near = None,
        dataDriven_sampleSize_far = None,
        near_far_comboSize = None):
        """
        Initialisation arguments
        ~~~~~~~~~~~~~~~
        torchModel: inference function, such as model in PyTorch
        lossFunc: loss function such as criterion in PyTorch
        optimizer : the optimizer object
        device: 'cuda' or 'cpu'
        dataMakerFunc: prepare data function,
            yout dataMakerFunc function must accept indices of 
            the data points that datos needs. 
            Then it must use these two to create data that is acceptable 
            by the inference function and labels
            that is acceptable by the loss function.
            tuple of two elements expected, 
                1: data that can be directly passed to model
                2: labels that can be passed to the loss funciton
        infer_size : maximum number of data points that 
            fit into your GPU memory
            default : 1
        classes : you have to provide an array 
            indexable over axis=0 that refers to the class of each data point. 
            If there is no class, set all of them to one. We will use this 
            vector to prepare indices for your dataset, as such it has no 
            default value.
            NOTE: this is a signed integer value and value 0 is preserved. For
                example, for MNIST, set it to labels+1. This way you wourln't
                have class 0.
        n_k : Divide the dataset into partitions by this number
            default: 10
        sampleSize : sample size.
            default: None, which will be 1% of data.
        n_epochs : number of epochs (that is how many times a network sees
            each data point in each sweep of k
            default: 8 (since out optimization needs 8 to 20)
        n_kSweeps : number of times we sweep k over the dataset.
            default: 4 (this makes the total epoch: 32)
        fit2FixedK : it only fits to worst residuals all the time
            default: 0.9
        n_correctFunc : a function that accepts predictions, labels and
            returns the number of correct 
        order: The way a model is trained using ascending/descending order 
            statistics, it accepts, ascend or descend 
            default: 'descend', could be 'descend'
        OutliersThreshold: How far from its mean, samples of a normal density
            are considered to be inliers? default: 4
        includeCloseOutliers: always mix up closest outliers with the current
            sample, default : False
        priorIndices: for sorting training data, then model will not be used to
            sort the data for the first time, After that after all epochs of 
            one fitting of SGD, the data will be sorted again according to
            the new neural network
            If you'd like to use parallel processing for updating indices and k
            you should keep checking the state of DATOS obj.
        sortAt: sort at each k sweep or at each update of k
            possible values: 'eachkSweep', 'eachkUpdate'
            default: 'eachkUpdate'
        fit2What: options: 'worst' and 'leastSeen', for 'worst' you can provide 
            'fit2FixedK', otherwise 'fit2FixedK' is set to 0.9
            default: None
        Fit2LeastSeenRate : how Ofter Fit2LeastSeen
            default : 4
        plotMSSEs : to see a visualization of how some data points are still 
            outliers, set this to True, default: False
        plotRelativeOrders : to see a visualization of how orders change from
            epoch to epoch set this to True, default: False
        saveCanvasInds : give these indices of test dataset, and a canvas
            pf their input and prediction images will be made periodically 
            if it is possible. Must be 1D numpy array of indices of images.
            default: None
        logTitle : log file Title, default: None
        lr_schedule: if provided, must be a numpy 1D array of size n_kSweeps
            and for each sweep over k, we will set the learning rate to the 
            kSweep-th value in lr_schedule. default: None
        dataDriven_LR_and_epochs: Would you like to allow cumulative residuals
            decide about LR and n_epochs for each data point?
            default True
        dataDriven_LR_near: LR for closer data points
            default LR
        dataDriven_LR_far: LR for further data points
            default LR
        dataDriven_nEpochs_near: nEpochs for close data points
            default n_epochs
        dataDriven_nEpochs_far: nEpochs for those that are far
            default n_epochs
        dataDriven_sampleSize_near: sample size for data points that are close
            default: sampleSize
        dataDriven_sampleSize_far: sample size for data points that are far
            default: sampleSize
        near_far_comboSize: Would you like to mix near and far indices to make
            a better random sample? set this to the number of divisions of 
            data-set to combine
            default: None
        """

        self.torchModel             = torchModel
        self.lossFunc               = lossFunc
        self.optimizer              = optimizer
        self.device                 = device
        self.dataMakerFunc          = dataMakerFunc
        self.infer_size             = infer_size
        self.n_correctFunc          = n_correctFunc
        self.startTime              = time.time()
        self.kSweeps                = 0
        self.n_epochs               = n_epochs
        self.n_kSweeps              = n_kSweeps
        self.sampleSize             = sampleSize
        self.order                  = order
        self.fit2FixedK             = fit2FixedK
        self.OutliersThreshold      = OutliersThreshold
        self.priorIndices           = priorIndices
        self.sortAt                 = sortAt
        self.fit2What               = fit2What
        self.Fit2LeastSeenRate      = Fit2LeastSeenRate
        self.plotMSSEs              = plotMSSEs
        self.plotRelativeOrders     = plotRelativeOrders
        self.saveCanvasInds         = saveCanvasInds
        self.includeCloseOutliers   = includeCloseOutliers
        self.n_k = n_k

        if( (self.fit2What == 'leastSeen') | 
            (self.fit2What =='worst')): 
            if(n_k<=2):
                print('The n_k is too low, you cannot fit to a specific range')
                print('Continuing without fit2What')
                self.fit2What = None
        
        n_pts = classes.shape[0]
        self.current_LR = self.optimizer.param_groups[0]['lr']
        self.lr_schedule  = lr_schedule
        if(self.lr_schedule is not None):
            assert(self.lr_schedule.shape[0]==self.n_kSweeps)
        
        if((numTestDataPoints==0) | (numTestDataPoints>n_pts)):
            numTestDataPoints = int(np.ceil(n_pts/10))
            print('numTestDataPoints is set to: ' + str(numTestDataPoints))
        allIndices = np.arange(n_pts).astype('uint64')
        
        classes = classes.astype('int')
        if(classes.min()<1):
            print('classes are supposed to be non-zero integers')
            print('since yours is not proper, I add its minimum plus one to it')
            classes+= classes.min() + 1

        ####################### test set and training set ######################
        self.train_indices = allIndices[:n_pts - numTestDataPoints]
        self.train_classes = classes[:n_pts - numTestDataPoints]
        self.train_classesList = np.unique(self.train_classes)
        self.test_indices = allIndices[n_pts - numTestDataPoints:]
        self.test_classes = classes[n_pts - numTestDataPoints:]
        self.test_classesList = np.unique(self.test_classes)
        ########################################################################
        
        self.n_trPts = int(self.train_indices.shape[0])
        self.trpts_n_visits = np.zeros(self.n_trPts)
        self.trpts_n_visits_perv = self.trpts_n_visits.copy()
        self.indicesUpdate_showProgress = indicesUpdate_showProgress
        self.botk = 0
        self.topk = 1
        self.k_perc = 1/self.n_k
        self.kCnt = 0
        self.losses_sortInds = np.arange(self.n_trPts).astype('int')
        assert(self.n_k>0)
        assert(self.n_trPts>0)
        assert(self.sampleSize>0)
        self.kList = np.linspace(0,1,self.n_k+1)
        if(self.order=='descend'):
            self.kList = np.flip(self.kList)
        
        self.meanTestLoss = np.finfo('float32').max
        self.epochs = 0
        self.sampleStart = 0
        self.sampleEnd = self.sampleSize
        
        self.indsToRemove = np.array([], dtype='int')
        self.maximumAcceptableTestLoss = 1e+9
        self.sortInds_byTrLoss = np.arange(self.n_trPts).astype('int')
        #self.sortInds_byTrLoss_perv = self.sortInds_byTrLoss

        self.best_meanTrainingLoss = np.finfo('float32').max
        self.sampleInds_record = np.array([[]])

        self.dataDriven_LR_and_epochs = dataDriven_LR_and_epochs
        if(self.dataDriven_LR_and_epochs):
            if(dataDriven_LR_near is None):
                self.dataDriven_LR_near = self.current_LR
            else:
                self.dataDriven_LR_near = dataDriven_LR_near
            if(dataDriven_LR_far is None):
                self.dataDriven_LR_far = self.current_LR
            else:
                self.dataDriven_LR_far = dataDriven_LR_far
            if(dataDriven_nEpochs_near is None):
                self.dataDriven_nEpochs_near = self.n_epochs
            else:
                self.dataDriven_nEpochs_near = dataDriven_nEpochs_near
            if(dataDriven_nEpochs_far is None):
                self.dataDriven_nEpochs_far = self.n_epochs
            else:
                self.dataDriven_nEpochs_far = dataDriven_nEpochs_far
            if(dataDriven_sampleSize_near is None):
                self.dataDriven_sampleSize_near = self.sampleSize
            else:
                self.dataDriven_sampleSize_near = dataDriven_sampleSize_near
            if(dataDriven_sampleSize_far is None):
                self.dataDriven_sampleSize_far = self.sampleSize
            else:
                self.dataDriven_sampleSize_far = dataDriven_sampleSize_far
            self.trainSet_LR = np.ones(self.n_trPts)
            self.trainSet_nEpochs = np.ones(self.n_trPts, dtype='int')

        self.near_far_comboSize = near_far_comboSize
        if(self.near_far_comboSize is not None):
            interPoints = \
                np.linspace(0, 
                            self.n_trPts, 
                            self.near_far_comboSize + 1).astype('int')[:-1]
            cnt = int(0)
            self.far_near_comboInds = np.array([], dtype='int')
            while(cnt<=interPoints[1]):
                 self.far_near_comboInds = np.concatenate(
                     (self.far_near_comboInds, 
                      cnt + interPoints), axis = 0)
                 cnt += 1
            self.far_near_comboInds = self.far_near_comboInds[:self.n_trPts]
            assert(self.far_near_comboInds.size==self.n_trPts)
                        
        ############################### Logging ###############################        
        self.savedTests_cnt = 0
        self.savedTrains_cnt = 0    
        self.log_trainInfCnt = 0
        self.saveModelSnapshot_cnt = 0
        if(logDIR is None):
            logDIR = './'
        if(logDIR[-1] != '/'):
            logDIR += '/'
        self.logDIR = logDIR + 'logs_' + str(int(self.startTime)) + '/'
        print('logDIR: ', self.logDIR)
        createDIR(self.logDIR)
        self.logDIR_trainingLoss = self.logDIR + 'trainingLoss/'
        createDIR(self.logDIR_trainingLoss)
        self.logDIR_trainingInference = self.logDIR + 'trainingInference/'
        createDIR(self.logDIR_trainingInference)
        self.logDIR_testLoss = self.logDIR + 'testLoss/'
        createDIR(self.logDIR_testLoss)
        self.logDIR_snapshots = self.logDIR + 'snapshots/'
        createDIR(self.logDIR_snapshots)
        if(self.plotMSSEs):
            self.logDIR_MSSEPlots = self.logDIR + 'MSSEPlots/'
            createDIR(self.logDIR_MSSEPlots)
        if(self.plotRelativeOrders):
            self.logDIR_OrdersChangePlots = self.logDIR + 'OrdersChangePlots/'
            createDIR(self.logDIR_OrdersChangePlots)
        if(self.saveCanvasInds is not None):
            self.logDIR_testImages = self.logDIR + 'testImages/'
            createDIR(self.logDIR_testImages)
        self.log_info = \
            logging.getLogger('Descend according to order statistics: info')
        self.log_scores = \
            logging.getLogger('Descend according to order statistics: scores')
        self.log_scores.setLevel(logging.INFO)
        fh = logging.FileHandler(self.logDIR + 'scores.log')
        fh.setLevel(logging.INFO)
        self.log_scores.addHandler(fh)
        self.log_info.setLevel(logging.INFO)
        fh = logging.FileHandler(self.logDIR + 'info.log')
        fh.setLevel(logging.INFO)
        self.log_info.addHandler(fh)
        self.log_scores.info("DATOS initialized - logging scores")
        if(logTitle is not None):
            self.log_info.info(logTitle)
        str2Log = printModelSize(self.torchModel)
        str2Log += '\ninfer_size' + ': ' + str(self.infer_size)
        str2Log += '\nn_epochs' + ': ' + str(self.n_epochs)
        str2Log += '\nn_kSweeps' + ': ' + str(self.n_kSweeps)
        str2Log += '\n' + 'sampleSize' + ': ' + str(self.sampleSize)
        str2Log += '\n' + 'order' + ': ' + str(self.order)
        str2Log += '\n' + 'fit2FixedK' + ': ' + str(self.fit2FixedK)
        str2Log += '\n' + 'OutliersThreshold' + ': ' + \
            str(self.OutliersThreshold)
        str2Log += '\n' + 'priorIndices?' + ': ' + \
            str(self.priorIndices is not None)
        str2Log += '\n' + 'sortAt' + ': ' + str(self.sortAt)
        str2Log += '\n' + 'fit2What' + ': ' + str(self.fit2What)
        str2Log += '\n' + 'Fit2LeastSeenRate' + ': ' + \
            str(self.Fit2LeastSeenRate)
        str2Log += '\n' + 'plotMSSEs?' + ': ' + str(self.plotMSSEs)
        str2Log += '\n' + 'plotRelativeOrders?' + ': ' + \
            str(self.plotRelativeOrders)
        str2Log += '\n' + 'saveCanvasInds' + ': '+ \
            str(self.saveCanvasInds is not None)
        str2Log += '\n' + 'includeCloseOutliers' + ': '+ \
            str(self.includeCloseOutliers)
        str2Log += '\n' + 'current_LR' + ': ' + str(self.current_LR)
        str2Log += '\n' + 'n_trPts' + ': ' + str(self.n_trPts)
        str2Log += '\n' + 'n_k' + ': ' + str(self.n_k)
        str2Log += '\n' + 'indicesUpdate_showProgress' + ': ' \
            + str(self.indicesUpdate_showProgress)
        str2Log += '\n' 'k_perc' + ': ' + str(self.k_perc)
        str2Log += '\n' 'dataDriven_LR_and_epochs' + ': ' + \
            str(self.dataDriven_LR_and_epochs)
        if(self.dataDriven_LR_and_epochs):
            str2Log += '\n' 'dataDriven_LR_near' + ': ' \
                + str(self.dataDriven_LR_near)
            str2Log += '\n' 'dataDriven_LR_far' + ': ' + \
                str(self.dataDriven_LR_far)
            str2Log += '\n' 'dataDriven_nEpochs_near' + ': ' \
                + str(self.dataDriven_nEpochs_near)
            str2Log += '\n' 'dataDriven_nEpochs_far' + ': ' \
                + str(self.dataDriven_nEpochs_far)     
            str2Log += '\n' 'dataDriven_sampleSize_near' + ': ' \
                + str(self.dataDriven_sampleSize_near)  
            str2Log += '\n' 'dataDriven_sampleSize_far' + ': ' \
                + str(self.dataDriven_sampleSize_far)
        self.log_info.info(str2Log)
        print(str2Log)
        ########################################################################
        
        ############################ test and sort #############################
        self.test()
        self.test_time_period = time.time() - self.last_test_time
        self.sortTrainSet()

    def useTorchModel(self, indices, 
                      updateModel = False, 
                      showProgress = False,
                      store_prediction = False):
        """use the netowrk by PytTorch
            Call this function when infering data for sorting or for trianing
            Input arguments:
            ~~~~~~~~~~~~~~~~
            updateModel: set to True if you like to update the network 
                with the given data and labels.
                default False
            showProgress: to show the progress bar in text
                default: False
            store_prediction: to return predictions duing test set it to True
                default: False
            Output argument:
            ~~~~~~~~~~~~~~~~
            losses
        """
        infer_size = self.infer_size
        n_correct = None
        prediction = None
        if(updateModel):
            data, labels = self.dataMakerFunc(indices)
            if(not torch.is_tensor(data)):
                data = torch.from_numpy(data).to(self.device)
            self.optimizer.zero_grad()
            preds = self.torchModel(data)
            if(not torch.is_tensor(labels)):
                labels = torch.from_numpy(labels).to(self.device)
            loss = self.lossFunc(preds, labels)
            loss.backward()
            self.optimizer.step()            
            data = data.detach().to('cpu')
            preds = preds.detach().to('cpu')
            labels = labels.detach().to('cpu')
            loss = loss.detach().to('cpu').numpy()
            losses = loss
            del data, preds, labels
            torch.cuda.empty_cache()
        else:
            n_pts = indices.shape[0]
            losses = np.zeros(n_pts, dtype='float32')
            if(showProgress):
                pBar = RGF.textProgBar(n_pts, 
                    title='Passing '+str(n_pts)+' data points to the network')
            ptCnt = 0
            n_correct = 0
            prediction_flag = False
            while (True):
                data, labels = \
                    self.dataMakerFunc(indices[ptCnt:ptCnt+infer_size])
                with torch.no_grad():
                    if(not torch.is_tensor(data)):
                        data = torch.from_numpy(data.astype('float')).float().to(self.device)
                    preds = self.torchModel(data)
                    if(store_prediction):
                        if(prediction_flag==False): #get size of it
                            prediction = \
                                np.zeros(((n_pts,) +  tuple(preds.shape[1:])))
                            prediction_flag = True
                    if(not torch.is_tensor(labels)):
                        labels = torch.from_numpy(labels).to(self.device)
                    for itemCnt in range(labels.shape[0]):
                        loss = self.lossFunc(preds[itemCnt], labels[itemCnt])
                        loss = loss.detach().to('cpu').numpy()
                        losses[ptCnt+itemCnt] = loss
                        if(store_prediction):
                            prediction[ptCnt+itemCnt] = \
                                preds[itemCnt].detach().to('cpu').numpy()
                    data = data.detach().to('cpu')
                    preds = preds.detach().to('cpu')
                    labels = labels.detach().to('cpu')

                    if(self.n_correctFunc is not None):
                        n_correct += self.n_correctFunc(preds.numpy(), 
                                                       labels.numpy())
    
                    del data, preds, labels
                    torch.cuda.empty_cache()
                
                ptCnt += infer_size
                if( ptCnt + infer_size > n_pts ):
                    infer_size = n_pts - ptCnt
                if( ptCnt >= n_pts):
                    break

                if(showProgress):
                    pBar.go(infer_size)

            if(showProgress):
                del pBar

        return(losses, n_correct, prediction)

    def reloadModel(self, checkpointFilePath = None):
        if(checkpointFilePath is None):
            checkpointFilePath = self.best_checkpointFilePath
        print('Reloading network')
        model.load_state_dict(torch.load(checkpointFilePath), strict=False)

    def lr_update(self, lr):
        for g in self.optimizer.param_groups:
            g['lr'] = lr
            
    def test(self):
        self.last_test_time = time.time()
        losses, n_correct, prediction = self.useTorchModel(
            self.test_indices,
            showProgress = True)
        meanTestLoss = losses.mean()
        
        if(meanTestLoss>self.maximumAcceptableTestLoss):
            print('Network exploded, mean Test Loss is ', meanTestLoss) 
        if(np.isnan(meanTestLoss)):
            print('Network gives nan')
            exit()
            
        str2Log =  'TEST: losses_mean: %f'%(losses.mean())
        str2Log += '\tmin: %f'%(losses.min())
        str2Log += '\tmax: %f'%(losses.max())
        str2Log += '\tstd: %f'%(losses.std())
        if(self.n_correctFunc is not None):
            str2Log += '\tn_correct: %d'%(n_correct)
        str2Log += '\ttime_stamp: %05d'%(time.time() - self.startTime)
        self.log_scores.info(str2Log)

        if(self.logDIR_testLoss is not None):
            np.savez(
                self.logDIR_testLoss + 'L_' + \
                    '%05d'%self.savedTests_cnt + '.npz',
                test_losses = losses,
                test_prediction = prediction,
                test_n_correct = n_correct,
                time_stamp = np.array([time.time() - self.startTime]),
                kSweeps = self.kSweeps,
                epochs = self.epochs)
                
            if(self.saveCanvasInds is not None):
                self.saveCanvasInds = np.arange(9).astype('int')
                data, label = \
                    self.dataMakerFunc(self.test_indices[self.saveCanvasInds])
                _, _, prediction = self.useTorchModel(\
                    self.test_indices[self.saveCanvasInds],
                    showProgress = False, store_prediction = True)
                n_imgs = label.shape[0]
                if(len(label.shape) !=4):
                    print('label should have 4 dimensions')
                    print('label shape: ', label.shape)
                    assert(False)
                n_R = label.shape[2]
                n_C = label.shape[3]
                n_img_C = int(np.ceil(self.saveCanvasInds.size**0.5))
                n_img_R = int(2*n_img_C)
                myCanvas = np.zeros((n_img_R*n_R, n_img_C*n_C), dtype='float32')
                rowCnt = 0
                clmCnt = 0
                for imgCnt in range(n_imgs):
                    inputB = np.squeeze(label[imgCnt])
                    outputB = np.squeeze(prediction[imgCnt])
                    if(inputB.max() != 0):
                        inputB /= inputB.max()
                    if(outputB.max() != 0):
                        outputB /= outputB.max()
                    myCanvas[(rowCnt  )*n_R: (rowCnt+1)*n_R, 
                             (clmCnt  )*n_C: (clmCnt+1)*n_C] = inputB
                    myCanvas[(rowCnt+1)*n_R: (rowCnt+2)*n_R, 
                             (clmCnt  )*n_C: (clmCnt+1)*n_C] = outputB
                    rowCnt += 2
                    if(rowCnt==n_img_R):
                        clmCnt += 1
                        rowCnt = 0
                myCanvas[myCanvas<0]=0
                plt.imshow(myCanvas)
                rowCnt = 0
                clmCnt = 0
                for xStart in range(0, n_img_R*n_R, n_R):
                    xEnd = xStart
                    yStart = 0
                    yEnd = n_img_C*n_C
                    plt.plot(np.array([yStart, yEnd])-0.5, 
                             np.array([xStart, xEnd])-0.5,
                             color='cyan', linewidth = 0.2)
                for yStart in range(0,  n_img_C*n_C, n_C):
                    yEnd = yStart
                    xStart = 0
                    xEnd = n_img_R*n_R
                    plt.plot(np.array([yStart, yEnd])-0.5, 
                             np.array([xStart, xEnd])-0.5, 
                             color='cyan', linewidth = 0.2)
                buf = self.logDIR_testImages \
                    + 'img_%06d'%self.savedTests_cnt + '.jpg'
                plt.savefig(buf, format='jpeg', dpi=600)
                plt.close()

        self.savedTests_cnt += 1
        return(losses, n_correct, prediction)
   
    def saveTrainingRecord(self):
        np.savez(
            self.logDIR_trainingLoss + 'T_' + \
                '%05d'%self.savedTrains_cnt + '.npz',
            kSweeps = self.kSweeps,
            losses = self.losses_record,
            sampleInds = self.sampleInds_record,
            time_stamp = self.timeStamp_record,
            trpts_n_visits = self.trpts_n_visits)
        self.savedTrains_cnt += 1

    def log_trainInference(self):
        str2Log =  'TRAIN: losses_mean: %f'%(self.trainingLosses.mean())
        str2Log += '\tMED: %f'%(np.median(self.trainingLosses))
        str2Log += '\tmin: %f'%(self.trainingLosses.min())
        str2Log += '\tmax: %f'%(self.trainingLosses.max())
        str2Log += '\tMED: %f'%(np.median(self.trainingLosses))
        str2Log += '\tstd: %f'%(self.trainingLosses.std())
        str2Log += '\tn_correct: %d'%(self.train_n_correct)
        self.log_scores.info(str2Log)
        print(str2Log, flush = True)
        
        np.savez(
            self.logDIR_trainingInference + 'T_' + \
                '%05d'%self.log_trainInfCnt + '.npz',
            train_losses = self.trainingLosses,
            train_n_correct = self.train_n_correct,
            train_classes = self.train_classes,
            time_stamp = np.array([time.time() - self.startTime]))

        if(self.plotMSSEs):
            errs = (self.trainingLosses[self.sortInds_byTrLoss]).copy()
            errs2 = (errs**2).copy()
            cumilSum2 = np.cumsum(errs2)/np.arange(1, 1 + errs2.shape[0])
            cumilSum2 = cumilSum2[:-1].copy()
            MSSECrit2 = errs2[1:].copy()
            MSSECrit2[cumilSum2==0] = 0
            MSSECrit2[cumilSum2>0] /= cumilSum2[cumilSum2>0]
            MSSECrit = MSSECrit2**0.5
            fig1 = plt.figure()
            plt.plot(MSSECrit, '.-')
            buf = self.logDIR_MSSEPlots + 'img%06d'%self.log_trainInfCnt+'.jpg'
            plt.savefig(buf,format='jpeg')
            plt.close(fig1)
            
        if(self.plotRelativeOrders):
            fig1 = plt.figure()
            plt.hexbin(self.sortInds_byTrLoss_perv, 
                       self.sortInds_byTrLoss, 
                       gridsize=self.n_k)
            buf = self.logDIR_OrdersChangePlots \
                + 'img%06d'%self.log_trainInfCnt + '.jpg'
            plt.savefig(buf,format='jpeg')
            plt.close(fig1)
        
        self.log_trainInfCnt += 1

    def maskVisited(self, unMaskAll = False):
        if(unMaskAll):
            self.train_classes = np.abs(self.train_classes)
            self.trpts_n_visits_perv = self.trpts_n_visits.copy()
        else:
            visitedInds = \
                np.where((self.trpts_n_visits>self.trpts_n_visits_perv) & 
                         (self.train_classes>0))[0]
            if(visitedInds.size > 0):
                self.train_classes[visitedInds] *= -1

            for idx, clss in enumerate(self.train_classesList):
                if( (self.train_classes==clss).sum() < self.sampleSize):
                    self.train_classes[self.train_classes==-clss] = clss

    def computeChangesInParams(self, error_cumsum, 
                               param_near, param_far, 
                               q_min = 10, q_max = 90):    
        error_cumsum -= np.percentile(error_cumsum, q = 10)
        error_cumsum /= np.percentile(error_cumsum, q = 90)
        error_cumsum[error_cumsum<0] = 0
        error_cumsum[error_cumsum>1] = 1
        error_cumsum *= (param_far - param_near) 
        error_cumsum += param_near
        return(error_cumsum)

    def calc_LR_and_epochs(self):    
        n_pts_arange = np.arange(self.n_trPts, dtype = 'int')
        INV_sortInds = np.zeros(self.n_trPts, dtype='int')
        INV_sortInds[self.sortInds_byTrLoss] = n_pts_arange
        sortedLosses = self.trainingLosses[self.sortInds_byTrLoss]
        sLoss_cumsum = np.cumsum(sortedLosses)

        ########################### LR ###############################
        trainSet_LR = self.computeChangesInParams(
            error_cumsum = sLoss_cumsum.copy(), 
            param_near = self.dataDriven_LR_near, 
            param_far = self.dataDriven_LR_far)
        self.trainSet_LR = trainSet_LR[INV_sortInds]
        
        ########################### n_Epochs #########################                
        trainSet_nEpochs = self.computeChangesInParams(
            error_cumsum = sLoss_cumsum.copy(), 
            param_near = self.dataDriven_nEpochs_near, 
            param_far = self.dataDriven_nEpochs_far)
        self.trainSet_nEpochs = trainSet_nEpochs[INV_sortInds]

        ########################### sampleSize #######################       
        trainSet_sampleSize = self.computeChangesInParams(
            error_cumsum = sLoss_cumsum.copy(), 
            param_near = self.dataDriven_sampleSize_near, 
            param_far = self.dataDriven_sampleSize_far)
        self.trainSet_sampleSize = trainSet_sampleSize[INV_sortInds]

    def findClosestOutlier(self):
        n_classes = self.train_classesList.shape[0]
        self.first_outlier_ind = np.zeros(n_classes)
        for idx, clss in enumerate(self.train_classesList):
            clssInds = np.where(self.train_classes==clss)[0]
            scale = RGF.MSSE(inVec = self.trainingLosses[clssInds], 
                             MSSE_LAMBDA = 3, minimumResidual = 1e-10)
            sortedLosses = np.sort(self.trainingLosses[clssInds])
            maxInd = int(
                np.argmax(sortedLosses > self.OutliersThreshold*scale))
            self.first_outlier_ind[idx] = maxInd
            
            ###################### remove bias #########################
            
            if( (0 < maxInd) & (maxInd < 0.1*clssInds.size) ): 
                class_sortInds_byTrLoss = \
                    self.sortInds_byTrLoss[clssInds]
                crazyInds = class_sortInds_byTrLoss[:maxInd]
                self.train_classes[crazyInds] = \
                    -np.abs(self.train_classes[crazyInds]).astype('int')
        
    def sortTrainSet(self):
        self.sortInds_byTrLoss_perv = self.sortInds_byTrLoss.copy()
        if(self.priorIndices is not None):
            self.sortInds_byTrLoss = self.priorIndices.copy()
            self.trainingLosses = np.zeros(self.n_trPts, dtype='float32')
            self.train_n_correct = 0
            self.priorIndices = None
        elif(self.sortAt is None):
            np.random.shuffle(self.sortInds_byTrLoss)
            self.trainingLosses = np.zeros(self.n_trPts, dtype='float32')
            self.train_n_correct = 0
        else:
            self.trainingLosses, self.train_n_correct, _ = self.useTorchModel(\
                    self.train_indices,
                    showProgress = self.indicesUpdate_showProgress)
            #algebraic error here
            self.trainingLosses = np.abs(self.trainingLosses)
            self.sortInds_byTrLoss = np.argsort(self.trainingLosses)
        if(self.near_far_comboSize is not None):
            self.sortInds_byTrLoss = \
                self.sortInds_byTrLoss[self.far_near_comboInds]
            
    def track_change_in_indices(self, n_bins = 40):
        """Using changes in indices
        Probably use it as follows:
        learning_rate = np.maximum(np.exp(coeff*50) \
            /(np.exp(1)*1000), learning_rate_minimum)
        learning_rate = np.minimum(learning_rate, learning_rate_maximum)
        for param_group in optimizer.param_groups:
            param_group['lr'] = learning_rate
        """
        vec_j = np.array([np.ones(n_bins)])
        vec_r = np.array([np.arange(n_bins)])
        vec_r2 = vec_r*vec_r
        A = np.histogram2d(self.sortInds_byTrLoss_perv, 
                           self.sortInds_byTrLoss, 
                           n_bins)[0]
        _n = vec_j@A@vec_j.T
        _sig_x = vec_r@A@vec_j.T
        _sig_y = vec_j@A@vec_r.T
        _sig_x2 = vec_r2@A@vec_j.T
        _sig_y2 = vec_j@A@vec_r2.T
        _sig_xy = vec_r@A@vec_r.T
        coeff = (_n*_sig_xy - _sig_x*_sig_y) \
            / (np.sqrt(_n * _sig_x2 - (_sig_x)**2) \
                *np.sqrt(_n * _sig_y2 - (_sig_y)**2))
        return(np.squeeze(coeff))
        
    def updateKLimits(self):
        print('updating topk and botk ', end='')
        fit2What = None
        if(((self.fit2What == 'leastSeen') | 
                (self.fit2What =='worst')) & 
           (self.kSweeps>0) & 
           (self.kSweeps % self.Fit2LeastSeenRate == 0)):
            fit2What = self.fit2What
        if(self.fit2What == 'fit2Skewed'):
            fit2What = self.fit2What

        if(fit2What is None):
            botk = self.kList[self.kCnt]
            topk = self.kList[self.kCnt+1]
            print('by regular fitting.')
        elif(fit2What=='leastSeen'):
            visited_sortedByTrLoss = \
                self.trpts_n_visits[self.sortInds_byTrLoss]
            freqs = np.zeros(self.kList.shape[0]-2)
            tmp_kList = np.sort(self.kList)
            for idx in np.arange(self.kList.shape[0]-2):
                freqs[idx] = visited_sortedByTrLoss[\
                    int(tmp_kList[idx]*self.n_trPts):\
                    int((tmp_kList[idx+1])*self.n_trPts)].mean()
            leastSeenEdge = np.argmin(freqs)+1
            botk = tmp_kList[leastSeenEdge]
            topk = tmp_kList[leastSeenEdge+1]
            print('by fitting to least seen.')
        elif(fit2What=='worst'):
            botk = self.fit2FixedK
            topk = botk + self.k_perc
            print('by fitting to the worst.')
        elif(fit2What == 'fit2Skewed'):
            botk = self.kList[self.kCnt]
            topk = self.kList[self.kCnt+1]
            if(self.epochs>0):
                self.botk = botk - self.epochs * (topk / self.n_epochs)
             
        self.botk = np.minimum(botk, topk)
        self.topk = np.maximum(botk, topk)
        if(self.botk<0):
            self.botk = 0
            #self.topk = self.k_perc
        if(self.topk>1):
            self.topk = 1
            #self.botk = 1 - self.k_perc

    def get_subset_indices(self):
        narange = np.arange(self.n_trPts, dtype='int')
        sorted_origNumber = narange[self.sortInds_byTrLoss]
        sorted_classes = self.train_classes[self.sortInds_byTrLoss]
        subsetInds = np.array([], dtype='int')
        for idx, clss in enumerate(self.train_classesList):
            class_sorted_origNumber = \
                sorted_origNumber[sorted_classes == clss]
            n_pts = class_sorted_origNumber.shape[0]

            clss_n_pts = (np.abs(self.train_classes)==clss).sum()
            avail_n_pts = int(clss_n_pts*(self.topk - self.botk))
            midk = (self.botk + self.topk)/2
            midk_ind = midk*n_pts
            
            if(avail_n_pts*2 <= n_pts):
                min_s_ind = n_pts/2 - avail_n_pts/2
                max_e_ind = n_pts/2 + avail_n_pts/2
                if(midk_ind <= min_s_ind):
                    midk_ind = min_s_ind
                    s_ind = 0
                    e_ind = avail_n_pts
                elif(midk_ind > max_e_ind):
                    midk_ind = max_e_ind
                    s_ind = n_pts - avail_n_pts
                    e_ind = n_pts
                else:
                    s_ind = midk_ind - avail_n_pts/2
                    e_ind = midk_ind + avail_n_pts/2
            else:
                s_ind = 0
                e_ind = n_pts
            
            s_ind = int(s_ind)
            e_ind = int(e_ind)

            if((self.n_epochs>0) & (self.fit2What == 'fit2Skewed')):
                clss_k_Inds = \
                    class_sorted_origNumber[s_ind : e_ind : self.n_epochs]
            else:
                clss_k_Inds = \
                    class_sorted_origNumber[s_ind : e_ind]
            
            if(self.includeCloseOutliers):
                first_outlier_ind = int(self.first_outlier_ind[idx])
                endOutliers = int(first_outlier_ind + self.k_perc*n_pts)
                if(endOutliers>n_pts):
                    endOutliers = n_pts
                if(first_outlier_ind<endOutliers):
                    outliersInds = narange[\
                        first_outlier_ind: endOutliers] 
                    clss_k_Inds = np.concatenate((clss_k_Inds, 
                                                  outliersInds), axis = 0)

            subsetInds = np.concatenate((subsetInds, clss_k_Inds), axis = 0)
        subsetInds = np.unique(subsetInds)
        #subsetInds_argsort = np.argsort(self.trainingLosses[subsetInds])
        #subsetInds = subsetInds[subsetInds_argsort]
        if(self.order=='descend'):
            subsetInds = np.flip(subsetInds)
        return(subsetInds)

    def log_updateIndices(self):
        str2Log = 'TRAIN: kCnt: %2d'%(self.kCnt)
        str2Log += '\tepoch: %0.3f'%(self.epochs)
        str2Log += '\tbotk: %0.3f'%(self.botk)
        str2Log += '\ttopk: %0.3f'%(self.topk)
        str2Log += '\tLR: %0.6f'%(self.current_LR)
        str2Log += '\tn_epochs: %1d'%(self.n_epochs)
        self.log_scores.info(str2Log)
        print(str2Log, flush = True)

    def updateIndices(self):
        print('updating indices')
        self.subInds = self.get_subset_indices()
        if(self.dataDriven_LR_and_epochs):
            self.current_LR = self.trainSet_LR[self.subInds].mean()
            self.n_epochs = int(self.trainSet_nEpochs[self.subInds].mean())
            self.sampleSize = int(self.trainSet_sampleSize[self.subInds].mean())
            self.lr_update(self.current_LR)
        self.n_subInds = self.subInds.shape[0]
        self.log_updateIndices()
                
    def init_trainRecorder(self):
        self.sampleInds_record = np.array([], dtype='uint64')
        self.timeStamp_record = np.array([], dtype='uint64')
        self.losses_record = np.array([], dtype='float32')

    def update_log_info(self):
        timeStamp = (time.time() - self.startTime)
        allTicks = self.n_kSweeps*self.n_k*self.n_epochs            
        currentTick = self.kSweeps*self.n_k*self.n_epochs \
            + self.kCnt*self.n_epochs \
            + self.epochs
        ETA = (allTicks - currentTick)*timeStamp/(currentTick + 1)
        str2Log = 'kSweeps: %02d'%(self.kSweeps + 1) \
            + '/' + str(self.n_kSweeps)
        str2Log += ', kCnt: %02d'%(self.kCnt+1) + '/' + str(self.n_k)
        str2Log += ', epochs: %02d'%(self.epochs+1) \
            + '/' + str(self.n_epochs)
        str2Log += ', subsetSize: %04d'%(self.n_subInds) 
        str2Log += '\tvisits_mean: %f'%(self.trpts_n_visits.mean())
        str2Log += '\tvisits_median: %f'%np.median(self.trpts_n_visits)
        str2Log += '\tvisits_std: %f'%(self.trpts_n_visits.std())
        str2Log += ', Time: %06d'%timeStamp
        str2Log += ', ETA: %06d'%ETA
        self.log_info.info(str2Log)
        print(str2Log, flush = True)

    def saveModelSnapshot(self):
        outFileFullPath = self.logDIR_snapshots \
                        + '%05d'%self.saveModelSnapshot_cnt + '.model'
        torch.save(self.torchModel.state_dict(), outFileFullPath)
        meanTrainingLoss = self.trainingLosses.mean()
        if(meanTrainingLoss < self.best_meanTrainingLoss):
            self.best_meanTrainingLoss = meanTrainingLoss
            self.best_checkpointFilePath = outFileFullPath
        self.saveModelSnapshot_cnt += 1

        str2Log = 'snapshot: ' + outFileFullPath + '\n'
        self.log_scores.info(str2Log)
        print(str2Log, flush = True)

    def dispense(self):
        """Data dispenser
        returns indices of a sample from the training data-set
        """

        if(self.kCnt >= self.n_k):
            self.maskVisited(unMaskAll = True)
            if(self.lr_schedule is not None):
                self.current_LR = self.lr_schedule[self.kSweeps] 
                self.lr_update(self.current_LR)
            self.kCnt = 0
            self.kSweeps += 1
            if(self.sortAt == 'eachkSweep'):
                self.sortTrainSet()
                self.log_trainInference()
            self.saveTrainingRecord()
            self.saveModelSnapshot()

        if(self.kSweeps >= self.n_kSweeps):
            return(None)

        if(self.sampleStart==0):
            if(self.epochs == 0):
                if(self.sortAt == 'eachkUpdate'):
                    self.sortTrainSet()
                    self.log_trainInference()
                self.maskVisited()
                if(self.dataDriven_LR_and_epochs is True):
                    self.calc_LR_and_epochs()
                if(self.OutliersThreshold is not None):
                    self.findClosestOutlier()
                self.updateKLimits()
                self.updateIndices()
                self.init_trainRecorder()
            self.update_log_info()
                            
        sampleInds = self.subInds[self.sampleStart : self.sampleEnd]
        
        #print('self.sampleStart: ', self.sampleStart, 
        #      ', sampleInds:', sampleInds )
        
        self.sampleStart += self.sampleSize
        self.sampleEnd = self.sampleStart + self.sampleSize
        if(self.sampleEnd > self.n_subInds):
            self.sampleEnd = self.n_subInds
        
        if(self.sampleStart >= self.n_subInds):
            self.sampleStart = 0
            self.sampleEnd = self.sampleSize
            self.epochs += 1
            if(self.fit2What == 'fit2Skewed'):
                self.updateKLimits()
                self.updateIndices()
            
        if(self.epochs >= self.n_epochs):
            self.epochs = 0
            self.kCnt += 1
            
        if(time.time() - self.last_test_time > 10 * self.test_time_period):
            self.test()
            
        return(sampleInds)

    def addEntry_trainRecorder(self, _loss, _sampleInds):
        self.sampleInds_record = np.concatenate(
            (self.sampleInds_record, _sampleInds), axis = 0)
        self.timeStamp_record = np.concatenate(
            (self.timeStamp_record, 
             int(time.time() - self.startTime) + 0*_sampleInds), axis = 0)
        self.losses_record = np.concatenate(
            (self.losses_record, _loss + 0*_sampleInds), axis = 0)

    def trainStep(self):
        sampleInds = self.dispense()
        if(sampleInds is None):
            self.update_log_info()
            self.test()
            return(self.logDIR)
        else:
            loss, _, _ = self.useTorchModel(indices = sampleInds,
                                              updateModel = True)
            self.trpts_n_visits[sampleInds] += 1
            self.addEntry_trainRecorder(loss, sampleInds)
            return('continue')
        