import numpy as np
from argparse import ArgumentParser
import os
import fnmatch
import matplotlib.pyplot as plt
import cfelpyutils.crystfel_utils as cfelCryst
import cfelpyutils.geometry_utils as cfelGeom

usePolar           = False
usePretrained      = True
n_test             = 500
n_train            = 100000 + n_test
baseFrame          = 0
clen_m             = 0.2006
beamEenergy_eV     = 12000
pixelSize          = 1/13333.3
eigerMinRes        = 20
eigerMaxRes        = 2000
degreeGraduates    = 2
ourMaxRes          = 768
maxRes_A           = 2
patternDegs        = int(360*degreeGraduates)
patternRads        = int(ourMaxRes/maxRes_A)
patternW           = 768
patternH           = 768
pretrainedFileName = './model.model'
scratchFolder = '/gpfs/exfel/exp/SPB/202030/p900119/scratch/alireza/'
geometryFile = scratchFolder + 'eiger16ATPetra3/dep/eiger16M-P11_200mm.geom'
logDIR = scratchFolder + 'antiIndexer_logs/'
dSetFile = scratchFolder + 'eiger16ATPetra3/streams/lactamase/subSet_stream_larger.npz'#smaller.npz'#larger.npz'

myGeom = cfelCryst.load_crystfel_geometry(geometryFile)
geomMap = cfelGeom.compute_pix_maps(myGeom)
geomMap_X = geomMap[0]
geomMap_Y = geomMap[1]

centX = geomMap_X.mean()
centY = geomMap_Y.mean()

def n_correctFunc(preds, labels):
    inds = np.where( ( (labels == 0) & (preds <  0.5) ) \
                   | ( (labels == 1) & (preds >= 0.5) ) )[0]
    return(inds.shape[0])
    #return( (labels[preds<0.5] == 0).sum() + (labels[preds>0.5]==1).sum())

def vector2Reciprocal(xVec, yVec, clen_m, beamEenergy_eV, pixelSize):
    '''
    h_Plank = 4.135667662e-15
    c_light = 299792458
    beamEenergy_eV = 9300
    lambda_A = h_Plank * c_light / beamEenergy_eV * 1e10
    DVal = clen_mm * 1e-3 + coffset_m
    '''
    lambda_A = 12398.4197386 / beamEenergy_eV

    xVec_m = xVec*pixelSize
    yVec_m = yVec*pixelSize
    
    k_pred = lambda_A*(xVec_m**2 + yVec_m**2 + clen_m**2)**0.5
    x_recip = xVec_m/k_pred
    y_recip = yVec_m/k_pred
    return(x_recip, y_recip)

def detector2Ewald(pix_x, pix_y, pix_z):
    # ew_rad is in pixels
    # we know: ew_pix_z/ew_rad = (pix_dist - ew_rad)/pix_dist
    pix_dist = np.sqrt((pix_x*pix_x + pix_y*pix_y + pix_z*pix_z))
    factor = pix_z/pix_dist
    ew_pix_x = pix_x * factor
    ew_pix_y = pix_y * factor
    ew_pix_z = pix_z * (1 - factor)
    ew_pix_x = ew_pix_x[None, :]
    ew_pix_y = ew_pix_y[None, :]
    ew_pix_z = ew_pix_z[None, :]
    return(np.concatenate((ew_pix_x, ew_pix_y, ew_pix_z), axis=0))

def ewald2vec_proj(pix_x, pix_y, pix_z, proj_vecs):
    ew_pix_coord = detector2Ewald(pix_x, pix_y, pix_z)
    
    #fig = scatter3(ew_pix_coord, returnFigure = True)
    #scatter3(200*proj_vecs, inFigure=fig)

    proj_components = proj_vecs.T @ ew_pix_coord
    
    imS = 512
    
    proj_components = (proj_components + imS).astype('int')
    proj_components[proj_components>=2*imS] = 2*imS - 1
    proj_components[proj_components<0] = 0
    vecLocs = np.tile(np.array([np.arange(proj_components.shape[0])]).T, 
                      (1, proj_components.shape[1]))
    
    projImage = np.zeros((proj_vecs.shape[1], 2*imS), dtype='float32')
    
    projImage[vecLocs, proj_components] = 1
    #tst = projImage.detach().cpu().numpy()
    #plt.imshow(tst), plt.show()
    #plt.plot(tst.mean(1)), plt.show()
    #projFFT = np.fft.fft2(projImage.detach().cpu().numpy())
    #plt.imshow(np.abs(projFFT), vmax=1000), plt.show()
    return(projImage)

class diffractionMaker:
    def __init__(self, indexedOrNot, 
                       peaksX,
                       peaksY,
                       peaksV,
                       crystBasis,
                       resolution_limit,
                       usePolar = False):
        self.usePolar = usePolar
        self.indexedOrNot = indexedOrNot
        self.peaksX = peaksX
        self.peaksY = peaksY
        self.peaksV = peaksV
        self.crystBasis = crystBasis
        self.resolution_limit = resolution_limit
        self.n_pts = indexedOrNot.shape[0]
        
        self.nPeaks = np.zeros(self.n_pts, dtype='uint32')
        self.theta_polar = np.zeros(peaksX.shape, dtype='int32')
        self.radius_polar = np.zeros(peaksX.shape, dtype='int32')
        self.peaksRow = np.zeros(peaksX.shape, dtype='int32')
        self.peaksClm = np.zeros(peaksX.shape, dtype='int32')
        self.peaksIntensity = np.zeros(peaksX.shape, dtype='float32')

        self.projections_vectors = getTriangularVertices(
            n = 256,
            rotationAngles = [np.pi, 0, 0],
            phi_start = 0,
            phi_end = np.pi/2,
            plotIt = False).astype('float32')
            
        self.ew_radius_in_pixels = 768 #4200*20/28
        self.proj_RCent = 384
        self.proj_CCent = 384
        
        self.recreateImage()
        
    def recreateImage(self):
        self.peaksV[self.peaksV>100000] = 100000
        self.indexedOrNot = (self.indexedOrNot).astype('float32')
        pBar = textProgBar(self.n_pts, 
            title='turning ' + str(self.n_pts) + \
                ' patterns into polar coordinates')
        for frmCnt in range(self.n_pts):
            frm_peaksX = self.peaksX[frmCnt]
            frm_peaksY = self.peaksY[frmCnt]

            _peaksX = frm_peaksX.astype('int32')
            _peaksY = frm_peaksY.astype('int32')
            frm_peaksX = geomMap_X[_peaksX, _peaksY]
            frm_peaksY = geomMap_Y[_peaksX, _peaksY]
            res = (frm_peaksX**2 + frm_peaksY**2)**0.5

            goodResPeaks = np.where((eigerMinRes<res)&(res<eigerMaxRes))[0]
            x_recip, y_recip = vector2Reciprocal(
                frm_peaksX[goodResPeaks], 
                frm_peaksY[goodResPeaks], 
                clen_m, 
                beamEenergy_eV, 
                pixelSize)

            theta_polar = np.arctan2(y_recip,x_recip)*180/(np.pi)+180
            radius_polar = (y_recip**2+x_recip**2)**0.5

            goodResPeaks = np.where(radius_polar*ourMaxRes \
                <int(ourMaxRes/maxRes_A))[0]

            nPeaksHere = int(goodResPeaks.shape[0])

            self.nPeaks[frmCnt] = nPeaksHere
            
            self.theta_polar[frmCnt, :nPeaksHere] = \
                (theta_polar[goodResPeaks]*degreeGraduates).astype('int32')
            self.radius_polar[frmCnt, :nPeaksHere] = \
                (radius_polar[goodResPeaks]*ourMaxRes).astype('int32')
            
            self.peaksRow[frmCnt, :nPeaksHere] = \
                (x_recip[goodResPeaks]*patternW + patternW/2).astype('int32')
            self.peaksClm[frmCnt, :nPeaksHere] = \
                (y_recip[goodResPeaks]*patternH + patternH/2).astype('int32')

            self.peaksIntensity[frmCnt, :nPeaksHere] = \
                self.peaksV[frmCnt, goodResPeaks]
                        
            pBar.go()
        del pBar
        print('Datamaker initialized')
        
    def __call__(self, sampleIndices):
    
        try:
            n_pts = sampleIndices.shape[0]
        except:
            n_pts = 1
            sampleIndices = np.array([sampleIndices])
                
        if(self.usePolar):
            netInput = np.zeros((patternDegs, patternRads), dtype='float32')
        else:
            netInput = np.zeros((256, 1024), dtype='float32')
        netInput = np.tile(netInput, (n_pts, 1, 1, 1))
        for frmCnt in range(n_pts):
            frmInd = sampleIndices[frmCnt]
            nPeaks = self.nPeaks[frmInd]
            if(nPeaks):
                if(self.usePolar):
                    patternRow = \
                        self.theta_polar[frmInd, :nPeaks]
                    patternClm = \
                        self.radius_polar[frmInd, :nPeaks]
                else:
                    patternRow = \
                        (self.peaksRow[frmInd, :nPeaks])
                    patternClm = \
                        (self.peaksClm[frmInd, :nPeaks])

                projImage = ewald2vec_proj(patternRow - self.proj_RCent, 
                                           patternClm - self.proj_CCent, 
                                           self.ew_radius_in_pixels, 
                                           self.projections_vectors)
                netInput[frmCnt, 0] = projImage.copy()
   
        netOutput = np.array([self.indexedOrNot[sampleIndices]])
        netOutput = netOutput.T
                
        return(netInput, netOutput)

class trainingInferenceLog:
    def __init__(self, logFolder):
        self.logFolder = logFolder + 'trainingInference/'
        fileTemp = '*.npz'
        flist = fnmatch.filter(os.listdir(self.logFolder), fileTemp)
        flist.sort()
        
        buf = np.load(self.logFolder + flist[0])
        self.train_losses = np.array([buf['train_losses']])
        self.train_classes = np.array([buf['train_classes']])
        self.time_stamp = buf['time_stamp']
        self.train_n_correct = np.array([buf['train_n_correct']])
        for idx, fName in enumerate(flist):
            buf = np.load(self.logFolder + fName)
            self.train_losses = \
                np.concatenate( (self.train_losses, 
                                 np.array([buf['train_losses']])), axis = 0)
            self.train_classes = \
                np.concatenate( (self.train_classes, 
                                 np.array([buf['train_classes']])), axis = 0)
            self.time_stamp = \
                np.concatenate( (self.time_stamp, 
                                 buf['time_stamp']), axis = 0)
            self.train_n_correct = \
                np.concatenate( (self.train_n_correct, 
                                 np.array([buf['train_n_correct']])), axis = 0)
            
        print('I read ', len(flist), ' files')
        
    def show(self):
        plt.imshow(self.train_losses), plt.show()
        plt.imshow(self.train_classes), plt.show()        

class trainingLog:
    def __init__(self, logFolder):
        self.logFolder = logFolder + 'trainingLoss/'
        fileTemp = '*.npz'
        flist = fnmatch.filter(os.listdir(self.logFolder), fileTemp)
        flist.sort()
        
        buf = np.load(self.logFolder + flist[0])
        #buf['kSweeps'], 
        self.trpts_n_visits = buf['trpts_n_visits']
        N = self.trpts_n_visits.shape[0]
        self.losses = buf['losses']
        print(buf['sampleInds'].shape)
        #n_t, sSize = buf['sampleInds'].shape

        self.all_sampleInds = np.array([])

        #self.sampleInds = np.zeros((len(flist)*n_t*2, N))
        #for cnt, bufVal in enumerate(buf['sampleInds']):
        #    self.sampleInds[cnt, bufVal] = 1
        self.time_stamp = buf['time_stamp']
        samples_soFar = 0
        
        self.trpts_n_visits = np.array([self.trpts_n_visits])
        
        for idx, fName in enumerate(flist[1:]):
            buf = np.load(self.logFolder + fName)
            self.losses = \
                np.concatenate( (self.losses, 
                                 buf['losses']), axis = 0)
            self.trpts_n_visits = \
                np.concatenate( (self.trpts_n_visits, 
                                 np.array([buf['trpts_n_visits']]) ), 
                                 axis = 0)
            self.time_stamp = \
                np.concatenate( (self.time_stamp, 
                                 buf['time_stamp']), axis = 0)

            #for cnt, bufVal in enumerate(buf['sampleInds']):
            #    self.sampleInds[samples_soFar + cnt, bufVal] = 1
            samples_soFar += buf['sampleInds'].shape[0]
            self.all_sampleInds = np.concatenate((self.all_sampleInds,
                np.squeeze((buf['sampleInds']).flatten())), axis=0)
        
        #self.sampleInds = self.sampleInds[:samples_soFar]
            
        print('I read ', len(flist), ' files')
        print('unique of all sample indices shape', 
              np.unique(self.all_sampleInds).shape)
        print('trpts_n_visits shape', self.trpts_n_visits.shape)
        
    def show(self):
        #'''
        for trpts_n_visits in self.trpts_n_visits:
            plt.plot(np.sort(trpts_n_visits), '.')
        plt.show()
        #'''
        #plt.hist(self.trpts_n_visits[-1], 100), plt.show()

class testLog:
    def __init__(self, logFolder):
        self.logFolder = logFolder + 'testLoss/'
        fileTemp = '*.npz'
        flist = fnmatch.filter(os.listdir(self.logFolder), fileTemp)
        flist.sort()
        
        buf = np.load(self.logFolder + flist[0])
        self.test_losses = np.array([buf['test_losses']])
        #self.test_prediction = np.array([buf['test_prediction']])
        self.time_stamp = buf['time_stamp']
        #self.test_n_correct = np.array([buf['test_n_correct']])
        for idx, fName in enumerate(flist):
            buf = np.load(self.logFolder + fName)
            self.test_losses = \
                np.concatenate( (self.test_losses, 
                                 np.array([buf['test_losses']])), axis = 0)
            self.time_stamp = \
                np.concatenate( (self.time_stamp, 
                                 buf['time_stamp']), axis = 0)
            
        print('I read ', len(flist), ' files')
        
    def show(self):
        plt.imshow(self.test_losses), plt.show()
        
if __name__ == '__main__':

    print('Reading ' + dSetFile)
    npzFile = np.load(dSetFile)
    print('File read!')

    if(False):
        inds2Keep = \
            np.arange(baseFrame, baseFrame + n_train + n_test).astype('int')
    if(True):
        orig_nPeaks            = npzFile['nPeaks']          
        orig_indexedOrNot      = npzFile['indexedOrNot']    
    
        inds2Keep_indexed = np.arange(orig_nPeaks.shape[0]).astype('int')
        inds2Keep_indexed = inds2Keep_indexed[(orig_indexedOrNot==1) \
                                            & (orig_nPeaks>10)]
        inds = PDF2Uniform(orig_nPeaks[inds2Keep_indexed], 
                           nUniPoints = int((n_train+ n_test)/2))
        inds2Keep_indexed = inds2Keep_indexed[inds]
    
        inds2Keep_notIndexed = np.arange(orig_nPeaks.shape[0]).astype('int')
        inds2Keep_notIndexed = inds2Keep_notIndexed[(orig_indexedOrNot==0) \
                                                  & (orig_nPeaks>10)]
        inds = PDF2Uniform(orig_nPeaks[inds2Keep_notIndexed], 
                           nUniPoints = int((n_train+ n_test)/2))
        inds2Keep_notIndexed = inds2Keep_notIndexed[inds]
        
        inds2Keep = np.concatenate((inds2Keep_indexed, 
                                    inds2Keep_notIndexed), axis=0)
        inds2Keep = np.sort(inds2Keep)
    
    nPeaks            = npzFile['nPeaks'][inds2Keep]          
    indexedOrNot      = npzFile['indexedOrNot'][inds2Keep]    
    peaksX            = npzFile['peaksX'][inds2Keep]          
    peaksY            = npzFile['peaksY'][inds2Keep]          
    peaksV            = npzFile['pIntensity'][inds2Keep]      
    crystBasis        = npzFile['crystBasis'][inds2Keep]      
    resolution_limit  = npzFile['resolution_limit'][inds2Keep]
    crystCellP        = npzFile['crystCellP'][inds2Keep]      

    logDIR = '/gpfs/exfel/exp/SPB/202030/p900119/scratch/alireza/antiIndexer_logs/logs_1619772383/'      
    assert(os.path.isdir(logDIR))

    #logDIR_snapshots            = logDIR + 'snapshots/'
    #logDIR_testImages           = logDIR + 'testImages/'
    #logDIR_MSSEPlots            = logDIR + 'MSSEPlots/'
    #logDIR_OrdersChangePlots    = logDIR + 'OrdersChangePlots/'
    
    #trainingLogLog_obj = trainingLog(logDIR)
    #trainingLogLog_obj.show()
    trainingLossLog_obj = trainingInferenceLog(logDIR)
    
    trainingLossLog_obj.show()
    #trainingLossLog_obj.show()